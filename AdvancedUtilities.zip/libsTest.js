const au = require("./index");
async function Main(){
//const test = await fs.Create("message","txt","hi user");
/*const newContent = await fs.Delete("./message.txt");
Console.Open()
//Console.WriteLine(test);
Console.WriteLine(newContent)
Console.Close();*/
}
Main();
